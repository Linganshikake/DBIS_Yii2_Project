# Page Clipper（Chrome/Edge 插件，Manifest V3）

## 功能
- 一键复制当前页面 **标题 + URL**
- 可选把当前页面“选中文本”一起复制
- 弹窗显示复制结果，并写入剪贴板

## 安装
1. Chrome：`chrome://extensions/` 或 Edge：`edge://extensions/`
2. 开启“开发者模式”
3. 点击“加载已解压的扩展程序 / Load unpacked”
4. 选择本目录（含 manifest.json 的文件夹）

## 代码要点
- `chrome.tabs.query`：获取当前标签页
- `chrome.scripting.executeScript`：在页面中读取 title/url/selection
- `navigator.clipboard.writeText`：写入剪贴板
