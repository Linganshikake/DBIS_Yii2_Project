async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs || tabs.length === 0) throw new Error("未找到活动标签页");
  return tabs[0];
}

async function queryPageInfo(tabId, includeSelection) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (includeSel) => {
      const title = document.title || "(no title)";
      const url = location.href;
      const selection = includeSel ? (window.getSelection()?.toString() || "") : "";
      return { title, url, selection };
    },
    args: [includeSelection],
  });
  return result;
}

function formatClip({ title, url, selection }) {
  const lines = [];
  lines.push(title);
  lines.push(url);
  if (selection && selection.trim().length > 0) {
    lines.push("");
    lines.push("—— 选中文本 ——");
    lines.push(selection.trim());
  }
  return lines.join("\n");
}

async function copyToClipboard(text) {
  await navigator.clipboard.writeText(text);
}

const $ = (id) => document.getElementById(id);

$("copyBtn").addEventListener("click", async () => {
  $("status").textContent = "处理中...";
  $("status").className = "muted";

  try {
    const includeSelection = $("includeSelection").checked;
    const tab = await getActiveTab();
    const info = await queryPageInfo(tab.id, includeSelection);
    const clip = formatClip(info);

    await copyToClipboard(clip);

    $("out").textContent = clip;
    $("status").textContent = "已复制到剪贴板 ✅";
    $("status").className = "ok";
  } catch (e) {
    $("status").textContent = "失败：" + (e?.message || String(e));
    $("status").className = "err";
  }
});
