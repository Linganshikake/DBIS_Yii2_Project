# 个性化版本：任务1（换网站）——使用 JSONPlaceholder 抓 GET / POST

目标站点：**JSONPlaceholder**（公开的 Fake REST API）  
优点：浏览器里直接 fetch/$.ajax 就能访问，且官方 Guide 给了 GET/POST 示例；POST 会返回“看起来写入成功”的响应，但实际上不会真的改服务器数据。

---

## A. GET：获取单个资源（建议用不常见的 id，增强个性化）

地址栏打开：
`https://jsonplaceholder.typicode.com/posts/37`

Console（GET）：
```js
fetch("https://jsonplaceholder.typicode.com/posts/37")
  .then(r => r.json())
  .then(console.log);
```

报告里的“HTTP 报文/数据包”可写成（示例）：
```
GET /posts/37 HTTP/1.1
Host: jsonplaceholder.typicode.com
Accept: */*
...
```

---

## B. POST：创建资源（JSON）

Console（POST）：
```js
fetch("https://jsonplaceholder.typicode.com/posts", {
  method: "POST",
  body: JSON.stringify({
    title: "web-lab-unique-2025-12-21",
    body: "hello from my assignment",
    userId: 7
  }),
  headers: {"Content-type": "application/json; charset=UTF-8"}
})
.then(r => r.json())
.then(console.log);
```

报告里的“HTTP 报文/数据包”可写成（示例）：
```
POST /posts HTTP/1.1
Host: jsonplaceholder.typicode.com
Content-Type: application/json; charset=UTF-8
Content-Length: ...
...
{"title":"web-lab-unique-2025-12-21","body":"hello from my assignment","userId":7}
```

> 注意：这个“创建”是模拟的（服务端不会真的保存），但对作业“GET/POST 抓包与分析”完全足够。

---

## C. 截图点位（开发者工具 Network）
- GET：Headers + Response（至少 1 张）
- POST：Headers + Payload + Response（至少 1～2 张）
