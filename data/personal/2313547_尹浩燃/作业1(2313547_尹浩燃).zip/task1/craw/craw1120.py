import hashlib
from dataclasses import dataclass, field
from typing import Set, List, Dict, Optional
import os
import json
import time
import random
import logging
from datetime import datetime
from urllib.parse import urljoin, urlparse

import re
import mimetypes
import requests  # 新增：下载图片用

import jieba.analyse
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager  # 使用webdriver_manager

from selenium.common.exceptions import (
    InvalidSessionIdException,
    WebDriverException,
    TimeoutException,
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)


@dataclass
class NewsDeduplicator:
    seen_urls: Set[str] = field(default_factory=set)
    seen_titles: Set[str] = field(default_factory=set)
    content_hashes: Set[str] = field(default_factory=set)

    def __post_init__(self):
        self._load_history()

    def is_duplicate(self, url: str, title: str, content: str = None) -> bool:
        if url in self.seen_urls:
            return True
        if self._is_title_duplicate(title):
            return True
        if content and self._is_content_duplicate(content):
            return True
        return False

    def add_record(self, url: str, title: str, content: str = None):
        self.seen_urls.add(url)
        self.seen_titles.add(title)
        if content:
            self.content_hashes.add(self._hash_content(content))

    def save_history(self, filepath=".news_history.json"):
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump({
                    "urls": list(self.seen_urls),
                    "titles": list(self.seen_titles),
                    "content_hashes": list(self.content_hashes)
                }, f, ensure_ascii=False)
        except Exception as e:
            logging.error(f"保存历史数据失败: {e}")

    def _load_history(self, filepath=".news_history.json"):
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.seen_urls.update(data.get("urls", []))
                    self.seen_titles.update(data.get("titles", []))
                    self.content_hashes.update(data.get("content_hashes", []))
            except Exception as e:
                logging.error(f"加载历史数据失败: {e}")

    def _is_title_duplicate(self, title: str, threshold=0.8) -> bool:
        title_keywords = self._extract_keywords(title)
        for seen_title in self.seen_titles:
            if self._jaccard_similarity(title_keywords, self._extract_keywords(seen_title)) > threshold:
                return True
        return False

    def _is_content_duplicate(self, content: str) -> bool:
        return self._hash_content(content) in self.content_hashes

    @staticmethod
    def _extract_keywords(text: str, topK=5) -> Set[str]:
        return set(jieba.analyse.extract_tags(text, topK=topK))

    @staticmethod
    def _jaccard_similarity(set1: Set[str], set2: Set[str]) -> float:
        intersection = len(set1 & set2)
        union = len(set1 | set2)
        return intersection / union if union else 0

    @staticmethod
    def _hash_content(content: str) -> str:
        return hashlib.md5(content.encode('utf-8')).hexdigest()


class ToutiaoSeleniumCrawler:
    def __init__(self, output_dir="toutiao_data"):
        os.makedirs(output_dir, exist_ok=True)
        self.output_dir = output_dir
        self.deduplicator = NewsDeduplicator()
        self.duplicate_count = 0

        # === 稳定化 Chrome 启动参数 ===
        chrome_options = Options()
        chrome_options.add_argument("--headless=new")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--use-gl=swiftshader")
        chrome_options.add_argument("--disable-3d-apis")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1280,2000")
        chrome_options.add_argument("--lang=zh-CN,zh")
        chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        chrome_options.page_load_strategy = "eager"

        # —— 直连、忽略证书、禁 QUIC / HTTP3 ——
        chrome_options.add_argument("--no-proxy-server")
        chrome_options.add_argument("--proxy-auto-detect=false")
        chrome_options.add_argument("--disable-quic")
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_argument("--allow-running-insecure-content")
        chrome_options.set_capability("acceptInsecureCerts", True)

        # === Selenium Manager 匹配驱动 ===
        self._chrome_options = chrome_options
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

        # 设置超时
        self.timeout = 20
        try:
            self.driver.set_page_load_timeout(self.timeout)
            self.driver.set_script_timeout(self.timeout)
        except Exception:
            pass

        self.base_url = "https://www.toutiao.com"

        # 分段重启控制
        self._articles_since_restart = 0
        self._restart_every = 80

    # ===== 驱动重建 =====
    def _build_driver(self):
        try:
            if getattr(self, "driver", None):
                self.driver.quit()
        except Exception:
            pass
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=self._chrome_options)
        try:
            self.driver.set_page_load_timeout(self.timeout)
            self.driver.set_script_timeout(self.timeout)
        except Exception:
            pass

    # ===== 带断线重建的 get =====
    def _safe_get(self, url: str, retry: int = 1):
        try:
            self.driver.get(url)
            return
        except (InvalidSessionIdException, WebDriverException) as e:
            if retry <= 0:
                raise
            logging.warning(f"会话失效/浏览器异常，正在重建并重试：{e}")
            self._build_driver()
            self.driver.get(url)

    def _generate_filename(self, prefix="toutiao"):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        return f"{prefix}_{timestamp}.json"

    def retry_request(self, request_func, max_retries=3):
        retries = 0
        while retries < max_retries:
            try:
                return request_func()
            except Exception as e:
                retries += 1
                logging.warning(f"请求失败，正在重试 ({retries}/{max_retries}): {e}")
                time.sleep(3)
        raise Exception("最大重试次数已达到，停止尝试")

    # 获取新闻列表
    def get_news_list(self, count=50, max_scroll=50):
        try:
            self._safe_get(self.base_url)
            try:
                WebDriverWait(self.driver, self.timeout).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".feed-card-article-wrapper"))
                )
            except TimeoutException:
                logging.warning("列表页首屏等待超时，重建会话后重试一次")
                self._build_driver()
                self._safe_get(self.base_url)
                WebDriverWait(self.driver, self.timeout).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".feed-card-article-wrapper"))
                )

            scroll_count = 0
            while True:
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                items = soup.select('.feed-card-article-wrapper')

                logging.info(f"当前页面新闻条数: {len(items)}")
                if len(items) >= count or scroll_count >= max_scroll:
                    break

                self.driver.execute_script("window.scrollBy(0, document.body.scrollHeight * 0.6);")
                time.sleep(random.uniform(1.5, 2.5))
                scroll_count += 1

            unique_news = []
            for item in items:
                try:
                    # 过滤视频新闻
                    if item.select_one('video') or item.select_one('.video-tag') or item.select_one('.video-icon'):
                        continue

                    a = item.select_one('a')
                    t = item.select_one('.title')
                    if not a or not t:
                        continue

                    title = t.get_text().strip()
                    url = urljoin(self.base_url, a['href'])

                    if self.deduplicator.is_duplicate(url=url, title=title):
                        self.duplicate_count += 1
                        continue

                    unique_news.append({
                        'title': title,
                        'url': url,
                        'source': item.select_one('.source').get_text().strip() if item.select_one('.source') else '今日头条',
                        'publish_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })

                    if len(unique_news) >= count:
                        break
                except Exception as e:
                    logging.warning(f"解析新闻条目失败: {str(e)}")
                    continue

            logging.info(f"过滤掉 {self.duplicate_count} 条重复新闻，剩余 {len(unique_news)} 条文本新闻")
            return unique_news

        except Exception as e:
            logging.error(f"获取新闻列表失败: {str(e)}")
            return []

    def get_article_id(self, url: str) -> Optional[str]:
        """从 url 中尽量提取文章 ID（group_id）"""
        m = re.search(r"/(\d{16,20})(?:/|$)", url)
        if m:
            return m.group(1)
        all_nums = re.findall(r"(\d+)", url)
        if not all_nums:
            return None
        return max(all_nums, key=len)

    # 点赞数 API
    def fetch_like_count_api(self, article_id: str, referer_url: Optional[str] = None) -> Optional[str]:
        try:
            api_url = f"https://www.toutiao.com/article/{article_id}/info/"
            headers = {
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json, text/plain, */*",
            }
            if referer_url:
                headers["Referer"] = referer_url
            r = requests.get(api_url, headers=headers, timeout=12)
            if r.status_code == 200 and r.text.startswith("{"):
                data = r.json().get("data", {})
                val = data.get("digg_count", None)
                if val is not None:
                    return str(val)
        except Exception as e:
            logging.debug(f"点赞 info 接口失败: {e}")
        return None

    # 点赞数 DOM
    def fetch_like_count_dom(self, article_url: str, driver) -> str:
        try:
            driver.get(article_url)
            WebDriverWait(driver, 12).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "article, .content, .main, #root"))
            )
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight/3);")
            time.sleep(0.9)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(0.9)

            full_text = driver.execute_script("return document.body.innerText;") or ""
            full_text = re.sub(r"\s+", " ", full_text)

            m = re.search(r"(赞|点赞|喜欢)\s*([0-9]+(?:\.[0-9]+)?(?:万|亿)?)", full_text)
            if m:
                return _normalize_count_text(m.group(2))
            m = re.search(r"([0-9]+(?:\.[0-9]+)?(?:万|亿)?)\s*(赞|点赞|喜欢)", full_text)
            if m:
                return _normalize_count_text(m.group(1))

            texts = driver.execute_script("""
                const out=[];
                const nodes=[...document.querySelectorAll('button,span,div,i,em,strong,a')];
                for(const el of nodes){
                  const t=(el.innerText||'').trim();
                  const aria=el.getAttribute && el.getAttribute('aria-label');
                  if(t && /赞|点赞|喜欢|Like|like|up/.test(t)) out.push(t);
                  if(aria && /赞|点赞|喜欢|Like|like|up/.test(aria)) out.push(aria);
                  if(/digg|like|zan/.test(el.className||' ')) out.push(t||aria||'');
                }
                return out.slice(0,400);
            """) or []
            for t in texts:
                t = re.sub(r"\s+", " ", t)
                mm = re.search(r"([0-9]+(?:\.[0-9]+)?(?:万|亿)?)", t)
                if mm and re.search(r"赞|点赞|喜欢|Like|like|up", t):
                    return _normalize_count_text(mm.group(1))

        except Exception as e:
            logging.debug(f"点赞 DOM 抓取失败: {e}")
        return "0"
        
    # 其他方法继续...
    # 评论数 DOM
    def fetch_comments_dom(self, article_url: str, driver, max_comments: int = 20) -> List[str]:
        res: List[str] = []
        try:
            driver.get(article_url)
            WebDriverWait(driver, 12).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "article, .content, .main, #root"))
            )
            for y in (0.5, 0.8, 1.0):
                driver.execute_script(f"window.scrollTo(0, document.body.scrollHeight*{y});")
                time.sleep(0.9)

            _click_possible_buttons(driver, ["评论", "更多评论", "展开更多评论", "查看更多", "展开", "加载更多"], max_click=4)
            time.sleep(0.9)

            selector_groups = [
                'div[class*="comment"] li',
                'div[class*="comment"] p',
                'div[class*="Comment"] li',
                'div[data-node="comments"] *',
                '[data-comment-id]',
                'ul[class*="comment"] li',
            ]
            seen = set()
            for sel in selector_groups:
                items = driver.execute_script(
                    """
                    const nodes=[...document.querySelectorAll(arguments[0])];
                    return nodes.map(el => (el.innerText||'').trim()).filter(Boolean);
                    """,
                    sel,
                ) or []
                for t in items:
                    t = _postprocess_comment(t)
                    if _is_junk_comment(t):
                        continue
                    if t in seen:
                        continue
                    seen.add(t)
                    res.append(t)
                    if len(res) >= max_comments:
                        return res
            return res
        except Exception as e:
            logging.debug(f"评论 DOM 抓取失败: {e}")
        return res

    def fetch_comments_with_fallback(self, article_id: str, article_url: str, driver, max_comments: int = 20) -> List[str]:
        arr = self.fetch_comments_api(article_id, max_comments=max_comments)
        if arr is not None and len(arr) > 0:
            return arr[:max_comments]
        logging.debug("评论使用 DOM 回退")
        return self.fetch_comments_dom(article_url, driver, max_comments=max_comments)

    # 作者信息抓取
    def fetch_author_info(self, article_url: str, driver) -> Dict[str, str]:
        info: Dict[str, str] = {
            "author_likes": "",
            "author_followers": "",
            "author_following": "",
            "author_verified": "",
            "author_bio": "",
        }
        try:
            driver.get(article_url)
            WebDriverWait(driver, 12).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "article, .content, .main, #root"))
            )
            soup = BeautifulSoup(driver.page_source, "html.parser")

            link_tag = soup.select_one("a.author-name, a[href*='/c/user/'], a[href*='/user/'], a[href*='/profile/']")
            if not link_tag:
                logging.info("未找到作者主页链接")
                return info

            author_url = link_tag.get("href") or ""
            if author_url.startswith("/"):
                author_url = "https://www.toutiao.com" + author_url

            driver.get(author_url)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight/3);")
            time.sleep(1.2)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1.2)

            full_text = _wait_for_text_contains(
                driver, keywords=["粉丝", "获赞", "关注", "认证", "简介"], timeout=7.0, poll=0.6
            )
            if not full_text:
                full_text = driver.execute_script("return document.body.innerText;") or ""
            full_text = re.sub(r"\s+", " ", full_text)

            m1 = re.search(r"([\d\.]+[万亿]?)\s*获赞", full_text)
            m2 = re.search(r"([\d\.]+[万亿]?)\s*粉丝", full_text)
            m3 = re.search(r"([\d\.]+[万亿]?)\s*关注(?!.*(我们|按钮|一下))", full_text)
            m4 = re.search(r"认证[:：]?\s*([^\s]+)", full_text)
            m5 = re.search(r"简介[:：]?\s*(.+?)(?=$|\s{2,})", full_text)

            info["author_likes"] = _normalize_count_text(m1.group(1)) if m1 else ""
            info["author_followers"] = _normalize_count_text(m2.group(1)) if m2 else ""
            info["author_following"] = _normalize_count_text(m3.group(1)) if m3 else ""
            info["author_verified"] = m4.group(1) if m4 else ""
            info["author_bio"] = _clean_bio(m5.group(1) if m5 else "", max_len=220)

        except Exception as e:
            logging.warning(f"作者信息抓取失败：{e}")

        return info

    # 下载图片
    def _download_images(self, image_urls, prefix, limit=10):
        """把图片保存到 output_dir/images/ 下，返回 [{'url':..., 'path':...}, ...]"""
        saved = []
        if not image_urls:
            return saved

        img_root = os.path.join(self.output_dir, "images")
        os.makedirs(img_root, exist_ok=True)

        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0",
            "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            "Referer": self.base_url,
        })

        for idx, url in enumerate(image_urls[:limit], start=1):
            try:
                r = session.get(url, timeout=15, stream=True)
                if r.status_code != 200:
                    continue

                parsed = urlparse(url)
                ext = os.path.splitext(parsed.path)[1]
                if not ext or len(ext) > 5:
                    ext = self._guess_ext_from_headers(r)

                fname = f"{prefix}_{idx:02d}{ext}"
                fpath = os.path.join(img_root, fname)

                with open(fpath, "wb") as f:
                    for chunk in r.iter_content(1024 * 32):
                        if chunk:
                            f.write(chunk)

                saved.append({"url": url, "path": fpath})
            except Exception:
                continue

        return saved

    def _guess_ext_from_headers(self, resp, fallback=".jpg"):
        ctype = resp.headers.get("Content-Type", "")
        ext = mimetypes.guess_extension(ctype.split(";")[0].strip()) if ctype else None
        return ext or fallback

    # 运行爬虫
    def run(self, count=50, filename=None, download_images=False, max_comments: int = 20):
        start_time = time.time()
        results = []

        try:
            news_list = self.retry_request(self.get_news_list, max_retries=3)
            if not news_list:
                raise ValueError("无法获取新闻列表")

            for news in news_list[:count]:
                try:
                    content, image_urls = self.retry_request(lambda: self.get_article(news['url']), max_retries=3)

                    if content:
                        record = dict(news)
                        record['content'] = content
                        record['crawl_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        record['images'] = []

                        # ===== 点赞 / 评论 / 作者信息 =====
                        extra_fields = {
                            "like_count": "0",
                            "comments": [],
                            "author_likes": "",
                            "author_followers": "",
                            "author_following": "",
                            "author_verified": "",
                            "author_bio": "",
                        }
                        article_id = self.get_article_id(news['url'])
                        if article_id:
                            extra_fields["like_count"] = self.fetch_like_count_with_fallback(
                                article_id, news['url'], self.driver
                            )
                            extra_fields["comments"] = self.fetch_comments_with_fallback(
                                article_id, news['url'], self.driver, max_comments=max_comments
                            )
                        author_info = self.fetch_author_info(news['url'], self.driver)
                        extra_fields.update(author_info)
                        record.update(extra_fields)

                        if download_images and image_urls:
                            prefix = self._generate_filename(prefix="img").replace(".json", "")
                            saved_imgs = self._download_images(image_urls, prefix=prefix, limit=10)
                            record['images'] = saved_imgs
                        else:
                            record['images'] = [{"url": u} for u in image_urls[:10]]

                        results.append(record)
                        self.deduplicator.add_record(url=news['url'], title=news['title'], content=content)

                    time.sleep(random.uniform(3, 6))
                except Exception as e:
                    logging.error(f"处理新闻失败: {str(e)}")
                    continue

            if results:
                filename = filename or self._generate_filename()
                filepath = os.path.join(self.output_dir, filename)
                try:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        json.dump(results, f, ensure_ascii=False, indent=2)
                    logging.info(f"保存 {len(results)} 条新闻到 {filepath}")
                    self.deduplicator.save_history()
                except Exception as e:
                    logging.error(f"保存数据失败: {e}")

        except Exception as e:
            logging.critical(f"爬虫运行失败: {str(e)}")
        finally:
            elapsed = time.time() - start_time
            logging.info(f"完成! 成功 {len(results)}/{count} 条, 过滤 {self.duplicate_count} 条重复, 耗时 {elapsed:.2f} 秒")
            try:
                self.driver.quit()
            except Exception:
                pass
            return results, filename if results else None


if __name__ == '__main__':
    for i in range(1, 601):
        print(f"\n=== 第{i}次运行 ===")
        try:
            crawler = ToutiaoSeleniumCrawler()
            # 开启图片下载：download_images=True；只存URL则设为 False
            results, saved_file = crawler.run(count=50, download_images=True)
            if results:
                print(f"\n保存文件: {saved_file}")
                print(f"示例新闻标题: {results[0]['title']}")
                print(f"正文前50字: {results[0]['content'][:50]}...")
                print(f"图片数量: {len(results[0].get('images', []))}")

            if i < 600:
                wait_time = random.randint(10, 30)
                print(f"\n等待{wait_time}秒后继续...")
                time.sleep(wait_time)
        except KeyboardInterrupt:
            print("\n用户中断程序执行")
            break
        except Exception as e:
            print(f"程序运行出错: {str(e)}")
            time.sleep(30)
            continue

