console.log("今日头条护眼插件已启动...");

// 获取文章正文的容器 (今日头条的正文通常在 article 标签或特定的 class 中)
// 这是一个循环检查，因为今日头条的内容是动态加载的
var interval = setInterval(function() {
    var articleContent = document.getElementsByTagName('article')[0];
    
    if (articleContent) {
        // 1. 修改背景颜色为护眼米色
        articleContent.style.backgroundColor = "#FDF6E3";
        articleContent.style.padding = "20px";
        articleContent.style.borderRadius = "10px";
        
        // 2. 找到所有的段落，把字号变大
        var paragraphs = articleContent.getElementsByTagName('p');
        for (let p of paragraphs) {
            p.style.fontSize = "22px";       // 字号加大
            p.style.lineHeight = "1.8";      // 行高加大
            p.style.color = "#333";          // 字体深灰
        }

        // 3. 在页面右下角添加一个浮动标记，证明插件在运行
        var badge = document.createElement('div');
        badge.innerText = "🍃 护眼模式";
        badge.style.position = "fixed";
        badge.style.bottom = "20px";
        badge.style.right = "20px";
        badge.style.background = "#4CAF50";
        badge.style.color = "white";
        badge.style.padding = "10px 20px";
        badge.style.borderRadius = "5px";
        badge.style.zIndex = "9999";
        document.body.appendChild(badge);

        clearInterval(interval); // 任务完成，停止检查
    }
}, 1000); // 每秒检查一次直到找到文章内容